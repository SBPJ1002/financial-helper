-- ============================================================
-- MIGRATION: Motor de Classificação Financeira
-- Stack: Node.js + TypeScript + PostgreSQL
-- ============================================================

-- Enum types
CREATE TYPE transaction_type AS ENUM ('income', 'fixed_expense', 'variable_expense');
CREATE TYPE payment_method AS ENUM ('pix', 'boleto', 'credit_card', 'debit_card', 'auto_debit', 'transfer', 'other');
CREATE TYPE classification_source AS ENUM ('user_rule', 'recurrence', 'keyword', 'default', 'manual');
CREATE TYPE review_status AS ENUM ('auto_classified', 'pending_review', 'user_confirmed', 'user_corrected');

-- ============================================================
-- 1. Transações (dados normalizados vindos da Pluggy)
-- ============================================================
CREATE TABLE transactions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    
    -- Dados originais da Pluggy
    pluggy_transaction_id VARCHAR(255) UNIQUE NOT NULL,
    pluggy_account_id VARCHAR(255) NOT NULL,
    raw_description TEXT NOT NULL,
    
    -- Dados normalizados
    normalized_description TEXT NOT NULL,
    amount DECIMAL(12, 2) NOT NULL,              -- positivo = entrada, negativo = saída
    transaction_date DATE NOT NULL,
    payment_method payment_method NOT NULL DEFAULT 'other',
    
    -- Identificação do recebedor/pagador
    counterpart_name VARCHAR(255),               -- nome normalizado
    counterpart_document VARCHAR(20),             -- CPF/CNPJ limpo
    counterpart_pix_key VARCHAR(255),             -- chave PIX quando disponível
    
    -- Dados de cartão de crédito
    installment_number INTEGER,
    installment_total INTEGER,
    card_last_four VARCHAR(4),
    
    -- Classificação
    transaction_type transaction_type NOT NULL DEFAULT 'variable_expense',
    category_id UUID REFERENCES categories(id),
    classification_source classification_source NOT NULL DEFAULT 'default',
    confidence_score DECIMAL(3, 2) NOT NULL DEFAULT 0.20,
    review_status review_status NOT NULL DEFAULT 'pending_review',
    
    -- Vínculo com recorrência (se detectada)
    recurrence_group_id UUID REFERENCES recurrence_groups(id),
    
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_transactions_user_date ON transactions(user_id, transaction_date DESC);
CREATE INDEX idx_transactions_user_type ON transactions(user_id, transaction_type);
CREATE INDEX idx_transactions_review ON transactions(user_id, review_status) WHERE review_status = 'pending_review';
CREATE INDEX idx_transactions_counterpart ON transactions(user_id, counterpart_document, counterpart_name);
CREATE INDEX idx_transactions_recurrence ON transactions(recurrence_group_id) WHERE recurrence_group_id IS NOT NULL;

-- ============================================================
-- 2. Categorias (hierárquicas)
-- ============================================================
CREATE TABLE categories (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name VARCHAR(100) NOT NULL,
    slug VARCHAR(100) NOT NULL UNIQUE,
    icon VARCHAR(50),
    color VARCHAR(7),                            -- hex color
    parent_id UUID REFERENCES categories(id),
    default_type transaction_type,               -- tipo sugerido para esta categoria
    is_system BOOLEAN NOT NULL DEFAULT TRUE,     -- categorias padrão do sistema
    sort_order INTEGER NOT NULL DEFAULT 0,
    
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Categorias padrão do sistema
INSERT INTO categories (name, slug, icon, color, default_type, sort_order) VALUES
    -- Receitas
    ('Salário', 'salario', 'banknote', '#22C55E', 'income', 1),
    ('Freelance', 'freelance', 'laptop', '#22C55E', 'income', 2),
    ('Investimentos', 'investimentos', 'trending-up', '#22C55E', 'income', 3),
    ('Outras Receitas', 'outras-receitas', 'plus-circle', '#22C55E', 'income', 4),
    
    -- Gastos Fixos
    ('Aluguel', 'aluguel', 'home', '#EF4444', 'fixed_expense', 10),
    ('Condomínio', 'condominio', 'building', '#EF4444', 'fixed_expense', 11),
    ('Energia', 'energia', 'zap', '#EF4444', 'fixed_expense', 12),
    ('Água', 'agua', 'droplets', '#EF4444', 'fixed_expense', 13),
    ('Internet', 'internet', 'wifi', '#EF4444', 'fixed_expense', 14),
    ('Telefone', 'telefone', 'smartphone', '#EF4444', 'fixed_expense', 15),
    ('Streaming', 'streaming', 'tv', '#EF4444', 'fixed_expense', 16),
    ('Seguro', 'seguro', 'shield', '#EF4444', 'fixed_expense', 17),
    ('Plano de Saúde', 'plano-saude', 'heart-pulse', '#EF4444', 'fixed_expense', 18),
    ('Academia', 'academia', 'dumbbell', '#EF4444', 'fixed_expense', 19),
    ('Assinaturas', 'assinaturas', 'repeat', '#EF4444', 'fixed_expense', 20),
    
    -- Gastos Variáveis
    ('Alimentação', 'alimentacao', 'utensils', '#F59E0B', 'variable_expense', 30),
    ('Transporte', 'transporte', 'car', '#F59E0B', 'variable_expense', 31),
    ('Lazer', 'lazer', 'gamepad', '#F59E0B', 'variable_expense', 32),
    ('Compras', 'compras', 'shopping-bag', '#F59E0B', 'variable_expense', 33),
    ('Saúde', 'saude', 'stethoscope', '#F59E0B', 'variable_expense', 34),
    ('Educação', 'educacao', 'graduation-cap', '#F59E0B', 'variable_expense', 35),
    ('Outros', 'outros', 'more-horizontal', '#F59E0B', 'variable_expense', 99);

-- ============================================================
-- 3. Grupos de Recorrência (transações agrupadas por padrão)
-- ============================================================
CREATE TABLE recurrence_groups (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    
    -- Padrão detectado
    label VARCHAR(255) NOT NULL,                 -- ex: "Aluguel - João Silva"
    counterpart_pattern VARCHAR(255),            -- padrão do recebedor usado pra match
    amount_avg DECIMAL(12, 2) NOT NULL,          -- valor médio detectado
    amount_tolerance DECIMAL(5, 2) DEFAULT 0.15, -- tolerância (15% padrão)
    day_of_month_avg INTEGER,                    -- dia médio de pagamento
    day_tolerance INTEGER DEFAULT 5,             -- tolerância em dias
    
    -- Classificação associada
    transaction_type transaction_type NOT NULL DEFAULT 'fixed_expense',
    category_id UUID REFERENCES categories(id),
    
    -- Contagem de ocorrências
    occurrence_count INTEGER NOT NULL DEFAULT 0,
    first_seen_at DATE NOT NULL,
    last_seen_at DATE NOT NULL,
    
    -- Status
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    confirmed_by_user BOOLEAN NOT NULL DEFAULT FALSE,
    
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_recurrence_user ON recurrence_groups(user_id) WHERE is_active = TRUE;

-- ============================================================
-- 4. Regras do Usuário (classificação manual/personalizada)
-- ============================================================
CREATE TABLE user_classification_rules (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    
    -- Critérios de match (qualquer combinação)
    match_counterpart_document VARCHAR(20),       -- CNPJ/CPF exato
    match_counterpart_name VARCHAR(255),          -- nome (fuzzy match)
    match_description_contains VARCHAR(255),      -- texto na descrição
    match_payment_method payment_method,          -- método de pagamento
    match_amount_min DECIMAL(12, 2),              -- faixa de valor
    match_amount_max DECIMAL(12, 2),
    
    -- Resultado da classificação
    transaction_type transaction_type NOT NULL,
    category_id UUID REFERENCES categories(id),
    custom_label VARCHAR(255),                    -- rótulo personalizado
    
    -- Metadados
    priority INTEGER NOT NULL DEFAULT 100,        -- menor = maior prioridade
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    times_applied INTEGER NOT NULL DEFAULT 0,
    
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_rules_user ON user_classification_rules(user_id) WHERE is_active = TRUE;

-- ============================================================
-- 5. Mapeamento de Palavras-chave (heurísticas do sistema)
-- ============================================================
CREATE TABLE keyword_mappings (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    
    keyword VARCHAR(255) NOT NULL,                -- palavra ou padrão
    match_field VARCHAR(50) NOT NULL DEFAULT 'normalized_description', -- campo onde buscar
    match_type VARCHAR(20) NOT NULL DEFAULT 'contains', -- contains, starts_with, exact
    
    -- Resultado sugerido
    transaction_type transaction_type NOT NULL,
    category_id UUID REFERENCES categories(id),
    confidence_boost DECIMAL(3, 2) NOT NULL DEFAULT 0.50,
    
    is_active BOOLEAN NOT NULL DEFAULT TRUE
);

-- Palavras-chave padrão do sistema
INSERT INTO keyword_mappings (keyword, match_field, transaction_type, category_id, confidence_boost) VALUES
    -- Receitas
    ('salario', 'normalized_description', 'income', (SELECT id FROM categories WHERE slug = 'salario'), 0.70),
    ('pagamento folha', 'normalized_description', 'income', (SELECT id FROM categories WHERE slug = 'salario'), 0.70),
    ('holerite', 'normalized_description', 'income', (SELECT id FROM categories WHERE slug = 'salario'), 0.70),
    ('prolabore', 'normalized_description', 'income', (SELECT id FROM categories WHERE slug = 'salario'), 0.65),
    
    -- Gastos Fixos - Moradia
    ('aluguel', 'normalized_description', 'fixed_expense', (SELECT id FROM categories WHERE slug = 'aluguel'), 0.65),
    ('condominio', 'normalized_description', 'fixed_expense', (SELECT id FROM categories WHERE slug = 'condominio'), 0.65),
    
    -- Gastos Fixos - Contas
    ('cpfl', 'normalized_description', 'fixed_expense', (SELECT id FROM categories WHERE slug = 'energia'), 0.70),
    ('enel', 'normalized_description', 'fixed_expense', (SELECT id FROM categories WHERE slug = 'energia'), 0.70),
    ('eletropaulo', 'normalized_description', 'fixed_expense', (SELECT id FROM categories WHERE slug = 'energia'), 0.70),
    ('cemig', 'normalized_description', 'fixed_expense', (SELECT id FROM categories WHERE slug = 'energia'), 0.70),
    ('light s.a', 'normalized_description', 'fixed_expense', (SELECT id FROM categories WHERE slug = 'energia'), 0.70),
    ('sabesp', 'normalized_description', 'fixed_expense', (SELECT id FROM categories WHERE slug = 'agua'), 0.70),
    ('copasa', 'normalized_description', 'fixed_expense', (SELECT id FROM categories WHERE slug = 'agua'), 0.70),
    ('sanepar', 'normalized_description', 'fixed_expense', (SELECT id FROM categories WHERE slug = 'agua'), 0.70),
    
    -- Gastos Fixos - Telecom/Internet
    ('vivo', 'counterpart_name', 'fixed_expense', (SELECT id FROM categories WHERE slug = 'internet'), 0.55),
    ('claro', 'counterpart_name', 'fixed_expense', (SELECT id FROM categories WHERE slug = 'internet'), 0.55),
    ('tim', 'counterpart_name', 'fixed_expense', (SELECT id FROM categories WHERE slug = 'telefone'), 0.55),
    ('oi s.a', 'counterpart_name', 'fixed_expense', (SELECT id FROM categories WHERE slug = 'internet'), 0.55),
    
    -- Gastos Fixos - Streaming/Assinaturas
    ('netflix', 'normalized_description', 'fixed_expense', (SELECT id FROM categories WHERE slug = 'streaming'), 0.80),
    ('spotify', 'normalized_description', 'fixed_expense', (SELECT id FROM categories WHERE slug = 'streaming'), 0.80),
    ('disney', 'normalized_description', 'fixed_expense', (SELECT id FROM categories WHERE slug = 'streaming'), 0.75),
    ('hbo max', 'normalized_description', 'fixed_expense', (SELECT id FROM categories WHERE slug = 'streaming'), 0.75),
    ('amazon prime', 'normalized_description', 'fixed_expense', (SELECT id FROM categories WHERE slug = 'streaming'), 0.75),
    ('youtube premium', 'normalized_description', 'fixed_expense', (SELECT id FROM categories WHERE slug = 'streaming'), 0.75),
    ('apple.com/bill', 'normalized_description', 'fixed_expense', (SELECT id FROM categories WHERE slug = 'assinaturas'), 0.70),
    ('google storage', 'normalized_description', 'fixed_expense', (SELECT id FROM categories WHERE slug = 'assinaturas'), 0.70),
    
    -- Gastos Variáveis
    ('ifood', 'normalized_description', 'variable_expense', (SELECT id FROM categories WHERE slug = 'alimentacao'), 0.75),
    ('rappi', 'normalized_description', 'variable_expense', (SELECT id FROM categories WHERE slug = 'alimentacao'), 0.75),
    ('uber eats', 'normalized_description', 'variable_expense', (SELECT id FROM categories WHERE slug = 'alimentacao'), 0.75),
    ('uber', 'normalized_description', 'variable_expense', (SELECT id FROM categories WHERE slug = 'transporte'), 0.60),
    ('99 taxis', 'normalized_description', 'variable_expense', (SELECT id FROM categories WHERE slug = 'transporte'), 0.65),
    ('mercadolivre', 'normalized_description', 'variable_expense', (SELECT id FROM categories WHERE slug = 'compras'), 0.60),
    ('amazon', 'normalized_description', 'variable_expense', (SELECT id FROM categories WHERE slug = 'compras'), 0.55),
    ('shopee', 'normalized_description', 'variable_expense', (SELECT id FROM categories WHERE slug = 'compras'), 0.65);

-- ============================================================
-- 6. Log de Classificação (auditoria)
-- ============================================================
CREATE TABLE classification_logs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    transaction_id UUID NOT NULL REFERENCES transactions(id) ON DELETE CASCADE,
    
    previous_type transaction_type,
    new_type transaction_type NOT NULL,
    previous_category_id UUID,
    new_category_id UUID,
    source classification_source NOT NULL,
    confidence_score DECIMAL(3, 2) NOT NULL,
    
    -- Qual regra/grupo gerou a classificação
    rule_id UUID REFERENCES user_classification_rules(id),
    recurrence_group_id UUID REFERENCES recurrence_groups(id),
    keyword_mapping_id UUID REFERENCES keyword_mappings(id),
    
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_classification_logs_tx ON classification_logs(transaction_id);

-- ============================================================
-- Trigger para updated_at automático
-- ============================================================
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER update_transactions_updated_at
    BEFORE UPDATE ON transactions
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_recurrence_groups_updated_at
    BEFORE UPDATE ON recurrence_groups
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_user_rules_updated_at
    BEFORE UPDATE ON user_classification_rules
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
