# Arquitetura — Motor de Classificação Financeira

## Visão Geral do Fluxo

```
┌─────────────┐     ┌──────────────────┐     ┌─────────────────────┐
│   Pluggy     │────▶│  Ingestão &       │────▶│  Motor de           │
│  Open Finance│     │  Normalização     │     │  Classificação      │
└─────────────┘     └──────────────────┘     └─────────┬───────────┘
                                                        │
                              ┌──────────────────────────┤
                              ▼                          ▼
                    ┌──────────────────┐     ┌─────────────────────┐
                    │  Classificação    │     │  Fila de Revisão    │
                    │  Automática       │     │  do Usuário         │
                    │  (alta confiança) │     │  (baixa confiança)  │
                    └────────┬─────────┘     └─────────┬───────────┘
                             │                          │
                             ▼                          ▼
                    ┌──────────────────────────────────────────────┐
                    │           Dashboard Financeiro                │
                    │  ┌────────┐  ┌────────────┐  ┌────────────┐ │
                    │  │Receitas│  │Gastos Fixos │  │Desp.Variáv.│ │
                    │  └────────┘  └────────────┘  └────────────┘ │
                    └──────────────────────────────────────────────┘
```

## Camadas do Sistema

### 1. Ingestão (Pluggy → Banco)

A Pluggy retorna transações com campos como:
- `description` — texto livre, geralmente bagunçado
- `amount` — valor (positivo = crédito, negativo = débito)
- `date` — data da transação
- `category` — categoria genérica da Pluggy (nem sempre útil)
- `paymentData` — dados de pagamento (PIX, boleto, cartão)
- `merchant.name` — nome do estabelecimento (quando disponível)
- `merchant.cnpj` — CNPJ (quando disponível)
- `creditCardMetadata.installmentNumber` — parcelas (cartão)

O **Normalizador** limpa esses dados antes de salvar:
- Normaliza descrições (remove códigos bancários, padroniza casing)
- Extrai identificador do recebedor (CNPJ, chave PIX, nome)
- Marca o método de pagamento (PIX, boleto, cartão, débito automático)

### 2. Motor de Classificação (3 níveis de prioridade)

**Nível 1 — Regras do Usuário (prioridade máxima)**
Regras criadas manualmente: "Transações para CNPJ X = Aluguel (gasto fixo)"

**Nível 2 — Detecção de Recorrência**
Algoritmo que analisa histórico de 2-3 meses:
- Mesmo recebedor (fuzzy match)
- Valor similar (tolerância de 15%)
- Periodicidade mensal (tolerância de ±5 dias)
Se detecta recorrência → classifica como **gasto fixo** com confiança alta.

**Nível 3 — Heurísticas por Categoria/Palavra-chave**
Mapeamento de palavras-chave e categorias MCC para classificação.
Confiança média — vai pra fila de revisão no primeiro mês.

**Fallback** — Tudo que não é classificado vira **despesa variável**.

### 3. Fluxo do Usuário

```
Primeiro acesso:
  1. Conecta banco via Pluggy
  2. Sistema puxa 90 dias de histórico
  3. Roda classificação automática
  4. Apresenta tela de ONBOARDING:
     - "Identificamos essas receitas recorrentes" → confirma
     - "Esses parecem gastos fixos" → confirma/ajusta
     - "Deseja criar regras para alguma transação?" → opcional
  5. Dashboard pronto

Uso mensal:
  1. Novas transações entram via webhook/sync da Pluggy
  2. Motor classifica automaticamente
  3. Transações sem match → notificação "5 transações para classificar"
  4. Regras do usuário se acumulam → sistema fica mais preciso
```

### 4. Modelo de Confiança

Cada classificação recebe um `confidence_score` de 0 a 1:
- **> 0.8** → Classificação automática, sem intervenção
- **0.5 - 0.8** → Classificação sugerida, aparece na fila de revisão
- **< 0.5** → Sem classificação, marcada como "variável" por padrão

O score é calculado combinando:
- Match com regra do usuário: +0.9
- Recorrência detectada (3+ meses): +0.8
- Recorrência detectada (2 meses): +0.6
- Match por palavra-chave/MCC: +0.5
- Sem match: 0.2 (default variável)
