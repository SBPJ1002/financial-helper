import { useState, useEffect } from "react";

// ============================================================
// Onboarding de Classificação Financeira
// Tela onde o usuário revisa e confirma as classificações automáticas
// ============================================================

const CATEGORY_ICONS = {
  income: "↗",
  fixed_expense: "📌",
  variable_expense: "💳",
};

const TYPE_LABELS = {
  income: "Receita",
  fixed_expense: "Gasto Fixo",
  variable_expense: "Despesa Variável",
};

const TYPE_COLORS = {
  income: { bg: "#ECFDF5", border: "#059669", text: "#065F46" },
  fixed_expense: { bg: "#FEF2F2", border: "#DC2626", text: "#991B1B" },
  variable_expense: { bg: "#FFFBEB", border: "#D97706", text: "#92400E" },
};

const SUGGESTED_CATEGORIES = [
  { id: "salario", label: "Salário", type: "income" },
  { id: "freelance", label: "Freelance", type: "income" },
  { id: "investimentos", label: "Investimentos", type: "income" },
  { id: "aluguel", label: "Aluguel", type: "fixed_expense" },
  { id: "condominio", label: "Condomínio", type: "fixed_expense" },
  { id: "energia", label: "Energia", type: "fixed_expense" },
  { id: "agua", label: "Água", type: "fixed_expense" },
  { id: "internet", label: "Internet", type: "fixed_expense" },
  { id: "telefone", label: "Telefone", type: "fixed_expense" },
  { id: "streaming", label: "Streaming", type: "fixed_expense" },
  { id: "assinaturas", label: "Assinaturas", type: "fixed_expense" },
  { id: "plano-saude", label: "Plano de Saúde", type: "fixed_expense" },
  { id: "academia", label: "Academia", type: "fixed_expense" },
  { id: "alimentacao", label: "Alimentação", type: "variable_expense" },
  { id: "transporte", label: "Transporte", type: "variable_expense" },
  { id: "lazer", label: "Lazer", type: "variable_expense" },
  { id: "compras", label: "Compras", type: "variable_expense" },
];

// Mock data — substitua pela API real
const MOCK_GROUPS = [
  {
    id: "g1",
    type: "income",
    label: "Empresa Tech Ltda",
    suggestedCategory: "salario",
    transactions: [
      { id: "t1", description: "Empresa Tech Ltda", amount: 8500, date: "2026-01-05", paymentMethod: "transfer" },
      { id: "t2", description: "Empresa Tech Ltda", amount: 8500, date: "2025-12-05", paymentMethod: "transfer" },
      { id: "t3", description: "Empresa Tech Ltda", amount: 8500, date: "2025-11-05", paymentMethod: "transfer" },
    ],
    recurrenceInfo: { avgAmount: 8500, frequency: "Mensal", dayOfMonth: 5, occurrences: 3 },
    confidenceScore: 0.92,
  },
  {
    id: "g2",
    type: "fixed_expense",
    label: "Aluguel - João Carlos",
    suggestedCategory: "aluguel",
    transactions: [
      { id: "t4", description: "Pix Aluguel João Carlos", amount: -2200, date: "2026-01-10", paymentMethod: "pix" },
      { id: "t5", description: "Pix Aluguel João Carlos", amount: -2200, date: "2025-12-10", paymentMethod: "pix" },
      { id: "t6", description: "Pix Aluguel João Carlos", amount: -2200, date: "2025-11-10", paymentMethod: "pix" },
    ],
    recurrenceInfo: { avgAmount: 2200, frequency: "Mensal", dayOfMonth: 10, occurrences: 3 },
    confidenceScore: 0.88,
  },
  {
    id: "g3",
    type: "fixed_expense",
    label: "Enel Energia",
    suggestedCategory: "energia",
    transactions: [
      { id: "t7", description: "Enel Energia SP", amount: -185.4, date: "2026-01-15", paymentMethod: "auto_debit" },
      { id: "t8", description: "Enel Energia SP", amount: -198.2, date: "2025-12-16", paymentMethod: "auto_debit" },
      { id: "t9", description: "Enel Energia SP", amount: -172.8, date: "2025-11-14", paymentMethod: "auto_debit" },
    ],
    recurrenceInfo: { avgAmount: 185.47, frequency: "Mensal", dayOfMonth: 15, occurrences: 3 },
    confidenceScore: 0.82,
  },
  {
    id: "g4",
    type: "fixed_expense",
    label: "Netflix",
    suggestedCategory: "streaming",
    transactions: [
      { id: "t10", description: "Netflix.com", amount: -55.9, date: "2026-01-22", paymentMethod: "credit_card" },
      { id: "t11", description: "Netflix.com", amount: -55.9, date: "2025-12-22", paymentMethod: "credit_card" },
    ],
    recurrenceInfo: { avgAmount: 55.9, frequency: "Mensal", dayOfMonth: 22, occurrences: 2 },
    confidenceScore: 0.85,
  },
  {
    id: "g5",
    type: "fixed_expense",
    label: "Sabesp",
    suggestedCategory: "agua",
    transactions: [
      { id: "t12", description: "Sabesp Cia Saneamento", amount: -87.3, date: "2026-01-20", paymentMethod: "boleto" },
      { id: "t13", description: "Sabesp Cia Saneamento", amount: -92.1, date: "2025-12-18", paymentMethod: "boleto" },
    ],
    recurrenceInfo: { avgAmount: 89.7, frequency: "Mensal", dayOfMonth: 19, occurrences: 2 },
    confidenceScore: 0.78,
  },
  {
    id: "g6",
    type: "fixed_expense",
    label: "Vivo Internet",
    suggestedCategory: "internet",
    transactions: [
      { id: "t14", description: "Vivo Fixo Internet", amount: -149.9, date: "2026-01-08", paymentMethod: "auto_debit" },
      { id: "t15", description: "Vivo Fixo Internet", amount: -149.9, date: "2025-12-08", paymentMethod: "auto_debit" },
      { id: "t16", description: "Vivo Fixo Internet", amount: -149.9, date: "2025-11-08", paymentMethod: "auto_debit" },
    ],
    recurrenceInfo: { avgAmount: 149.9, frequency: "Mensal", dayOfMonth: 8, occurrences: 3 },
    confidenceScore: 0.90,
  },
];

const PAYMENT_LABELS = {
  pix: "PIX",
  boleto: "Boleto",
  credit_card: "Cartão",
  debit_card: "Débito",
  auto_debit: "Déb. Auto.",
  transfer: "Transf.",
  other: "Outro",
};

function formatCurrency(val) {
  return new Intl.NumberFormat("pt-BR", { style: "currency", currency: "BRL" }).format(Math.abs(val));
}

function formatDate(dateStr) {
  return new Date(dateStr + "T12:00:00").toLocaleDateString("pt-BR", { day: "2-digit", month: "short" });
}

export default function OnboardingClassification() {
  const [step, setStep] = useState("loading");
  const [groups, setGroups] = useState([]);
  const [decisions, setDecisions] = useState({});
  const [expandedGroup, setExpandedGroup] = useState(null);
  const [editingGroup, setEditingGroup] = useState(null);

  useEffect(() => {
    setTimeout(() => {
      setGroups(MOCK_GROUPS);
      const initial = {};
      MOCK_GROUPS.forEach((g) => {
        initial[g.id] = {
          status: "pending",
          type: g.type,
          categoryId: g.suggestedCategory,
        };
      });
      setDecisions(initial);
      setStep("review");
    }, 1500);
  }, []);

  const confirmedCount = Object.values(decisions).filter((d) => d.status === "confirmed").length;
  const rejectedCount = Object.values(decisions).filter((d) => d.status === "rejected").length;
  const pendingCount = Object.values(decisions).filter((d) => d.status === "pending").length;
  const totalGroups = groups.length;

  function handleConfirm(groupId) {
    setDecisions((prev) => ({
      ...prev,
      [groupId]: { ...prev[groupId], status: "confirmed" },
    }));
  }

  function handleReject(groupId) {
    setDecisions((prev) => ({
      ...prev,
      [groupId]: { ...prev[groupId], status: "rejected" },
    }));
  }

  function handleChangeType(groupId, newType) {
    setDecisions((prev) => ({
      ...prev,
      [groupId]: { ...prev[groupId], type: newType, status: "confirmed" },
    }));
    setEditingGroup(null);
  }

  function handleChangeCategory(groupId, catId) {
    setDecisions((prev) => ({
      ...prev,
      [groupId]: { ...prev[groupId], categoryId: catId, status: "confirmed" },
    }));
  }

  function handleFinish() {
    const payload = {
      confirmedGroups: [],
      rejectedGroups: [],
      corrections: [],
    };

    for (const [groupId, decision] of Object.entries(decisions)) {
      const original = groups.find((g) => g.id === groupId);
      if (decision.status === "rejected") {
        payload.rejectedGroups.push(groupId);
      } else {
        payload.confirmedGroups.push(groupId);
        if (decision.type !== original.type || decision.categoryId !== original.suggestedCategory) {
          payload.corrections.push({
            groupId,
            newType: decision.type,
            newCategoryId: decision.categoryId,
          });
        }
      }
    }

    console.log("Onboarding payload:", JSON.stringify(payload, null, 2));
    setStep("done");
  }

  // ── Loading ──
  if (step === "loading") {
    return (
      <div style={styles.container}>
        <div style={styles.loadingCard}>
          <div style={styles.spinner} />
          <h2 style={styles.loadingTitle}>Analisando suas transações...</h2>
          <p style={styles.loadingText}>
            Estamos identificando padrões nos últimos 3 meses do seu extrato.
          </p>
        </div>
      </div>
    );
  }

  // ── Done ──
  if (step === "done") {
    return (
      <div style={styles.container}>
        <div style={styles.doneCard}>
          <div style={styles.doneIcon}>✓</div>
          <h2 style={styles.doneTitle}>Tudo configurado!</h2>
          <p style={styles.doneText}>
            {confirmedCount} grupo{confirmedCount !== 1 ? "s" : ""} confirmado{confirmedCount !== 1 ? "s" : ""}
            {rejectedCount > 0 && `, ${rejectedCount} rejeitado${rejectedCount !== 1 ? "s" : ""}`}.
            Suas próximas transações serão classificadas automaticamente.
          </p>
          <p style={styles.doneSubtext}>
            Você pode ajustar classificações a qualquer momento no dashboard.
          </p>
        </div>
      </div>
    );
  }

  // ── Review ──
  const incomeGroups = groups.filter((g) => decisions[g.id]?.type === "income" || g.type === "income");
  const expenseGroups = groups.filter((g) => (decisions[g.id]?.type || g.type) !== "income");

  return (
    <div style={styles.container}>
      {/* Header */}
      <div style={styles.header}>
        <h1 style={styles.title}>Revisão de Classificação</h1>
        <p style={styles.subtitle}>
          Encontramos <strong>{totalGroups} padrões recorrentes</strong> nas suas transações.
          Confirme ou ajuste cada um.
        </p>

        {/* Progress */}
        <div style={styles.progressBar}>
          <div
            style={{
              ...styles.progressFill,
              width: `${((confirmedCount + rejectedCount) / totalGroups) * 100}%`,
            }}
          />
        </div>
        <div style={styles.progressLabels}>
          <span style={styles.progressLabel}>
            <span style={{ ...styles.dot, background: "#059669" }} /> {confirmedCount} confirmado{confirmedCount !== 1 ? "s" : ""}
          </span>
          <span style={styles.progressLabel}>
            <span style={{ ...styles.dot, background: "#DC2626" }} /> {rejectedCount} rejeitado{rejectedCount !== 1 ? "s" : ""}
          </span>
          <span style={styles.progressLabel}>
            <span style={{ ...styles.dot, background: "#9CA3AF" }} /> {pendingCount} pendente{pendingCount !== 1 ? "s" : ""}
          </span>
        </div>
      </div>

      {/* Receitas */}
      {incomeGroups.length > 0 && (
        <div style={styles.section}>
          <h2 style={styles.sectionTitle}>
            <span style={styles.sectionIcon}>↗</span> Receitas Recorrentes
          </h2>
          {incomeGroups.map((group) => (
            <GroupCard
              key={group.id}
              group={group}
              decision={decisions[group.id]}
              expanded={expandedGroup === group.id}
              editing={editingGroup === group.id}
              onToggleExpand={() => setExpandedGroup(expandedGroup === group.id ? null : group.id)}
              onConfirm={() => handleConfirm(group.id)}
              onReject={() => handleReject(group.id)}
              onEdit={() => setEditingGroup(editingGroup === group.id ? null : group.id)}
              onChangeType={(t) => handleChangeType(group.id, t)}
              onChangeCategory={(c) => handleChangeCategory(group.id, c)}
            />
          ))}
        </div>
      )}

      {/* Gastos */}
      {expenseGroups.length > 0 && (
        <div style={styles.section}>
          <h2 style={styles.sectionTitle}>
            <span style={styles.sectionIcon}>📌</span> Gastos Recorrentes
          </h2>
          {expenseGroups.map((group) => (
            <GroupCard
              key={group.id}
              group={group}
              decision={decisions[group.id]}
              expanded={expandedGroup === group.id}
              editing={editingGroup === group.id}
              onToggleExpand={() => setExpandedGroup(expandedGroup === group.id ? null : group.id)}
              onConfirm={() => handleConfirm(group.id)}
              onReject={() => handleReject(group.id)}
              onEdit={() => setEditingGroup(editingGroup === group.id ? null : group.id)}
              onChangeType={(t) => handleChangeType(group.id, t)}
              onChangeCategory={(c) => handleChangeCategory(group.id, c)}
            />
          ))}
        </div>
      )}

      {/* Footer */}
      <div style={styles.footer}>
        <button
          style={{
            ...styles.finishButton,
            opacity: pendingCount > 0 ? 0.5 : 1,
          }}
          onClick={handleFinish}
        >
          {pendingCount > 0
            ? `Faltam ${pendingCount} para revisar`
            : "Finalizar Configuração"}
        </button>
        {pendingCount > 0 && (
          <button style={styles.skipButton} onClick={handleFinish}>
            Pular restantes e finalizar
          </button>
        )}
      </div>
    </div>
  );
}

function GroupCard({ group, decision, expanded, editing, onToggleExpand, onConfirm, onReject, onEdit, onChangeType, onChangeCategory }) {
  const currentType = decision?.type || group.type;
  const currentCategory = decision?.categoryId || group.suggestedCategory;
  const status = decision?.status || "pending";
  const colors = TYPE_COLORS[currentType];
  const categoryLabel = SUGGESTED_CATEGORIES.find((c) => c.id === currentCategory)?.label;

  const cardStyle = {
    ...styles.card,
    borderLeft: `4px solid ${colors.border}`,
    opacity: status === "rejected" ? 0.5 : 1,
    background: status === "confirmed" ? colors.bg : "#FFFFFF",
  };

  return (
    <div style={cardStyle}>
      {/* Main row */}
      <div style={styles.cardMain} onClick={onToggleExpand}>
        <div style={styles.cardInfo}>
          <div style={styles.cardLabel}>{group.label}</div>
          <div style={styles.cardMeta}>
            {formatCurrency(group.recurrenceInfo.avgAmount)} · {group.recurrenceInfo.frequency} · dia ~{group.recurrenceInfo.dayOfMonth}
          </div>
          <div style={styles.cardTags}>
            <span style={{ ...styles.tag, background: colors.bg, color: colors.text }}>
              {TYPE_LABELS[currentType]}
            </span>
            {categoryLabel && (
              <span style={styles.tagCategory}>{categoryLabel}</span>
            )}
            <span style={styles.tagConfidence}>
              {Math.round(group.confidenceScore * 100)}% confiança
            </span>
          </div>
        </div>

        <div style={styles.cardActions}>
          {status === "pending" && (
            <>
              <button
                style={styles.confirmBtn}
                onClick={(e) => { e.stopPropagation(); onConfirm(); }}
                title="Confirmar"
              >
                ✓
              </button>
              <button
                style={styles.editBtn}
                onClick={(e) => { e.stopPropagation(); onEdit(); }}
                title="Alterar classificação"
              >
                ✎
              </button>
              <button
                style={styles.rejectBtn}
                onClick={(e) => { e.stopPropagation(); onReject(); }}
                title="Não é recorrente"
              >
                ✕
              </button>
            </>
          )}
          {status === "confirmed" && (
            <span style={styles.statusConfirmed}>Confirmado ✓</span>
          )}
          {status === "rejected" && (
            <span style={styles.statusRejected}>Rejeitado</span>
          )}
        </div>
      </div>

      {/* Edit panel */}
      {editing && (
        <div style={styles.editPanel}>
          <div style={styles.editSection}>
            <span style={styles.editLabel}>Tipo:</span>
            <div style={styles.editOptions}>
              {Object.entries(TYPE_LABELS).map(([key, label]) => (
                <button
                  key={key}
                  style={{
                    ...styles.editOption,
                    background: currentType === key ? TYPE_COLORS[key].bg : "#F3F4F6",
                    border: `1px solid ${currentType === key ? TYPE_COLORS[key].border : "#D1D5DB"}`,
                    color: currentType === key ? TYPE_COLORS[key].text : "#374151",
                    fontWeight: currentType === key ? 600 : 400,
                  }}
                  onClick={() => onChangeType(key)}
                >
                  {CATEGORY_ICONS[key]} {label}
                </button>
              ))}
            </div>
          </div>
          <div style={styles.editSection}>
            <span style={styles.editLabel}>Categoria:</span>
            <div style={styles.editOptions}>
              {SUGGESTED_CATEGORIES.filter((c) => c.type === currentType).map((cat) => (
                <button
                  key={cat.id}
                  style={{
                    ...styles.editOption,
                    background: currentCategory === cat.id ? "#DBEAFE" : "#F3F4F6",
                    border: `1px solid ${currentCategory === cat.id ? "#3B82F6" : "#D1D5DB"}`,
                    fontWeight: currentCategory === cat.id ? 600 : 400,
                  }}
                  onClick={() => onChangeCategory(cat.id)}
                >
                  {cat.label}
                </button>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Expanded transactions */}
      {expanded && !editing && (
        <div style={styles.txList}>
          <div style={styles.txListHeader}>Transações encontradas:</div>
          {group.transactions.map((tx) => (
            <div key={tx.id} style={styles.txRow}>
              <span style={styles.txDate}>{formatDate(tx.date)}</span>
              <span style={styles.txDesc}>{tx.description}</span>
              <span style={styles.txMethod}>{PAYMENT_LABELS[tx.paymentMethod]}</span>
              <span style={{ ...styles.txAmount, color: tx.amount > 0 ? "#059669" : "#DC2626" }}>
                {tx.amount > 0 ? "+" : "-"}{formatCurrency(tx.amount)}
              </span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

// ── Styles ──
const styles = {
  container: {
    maxWidth: 720,
    margin: "0 auto",
    padding: "24px 16px",
    fontFamily: "'DM Sans', 'Segoe UI', system-ui, sans-serif",
    color: "#111827",
    minHeight: "100vh",
    background: "linear-gradient(180deg, #F8FAFC 0%, #EFF6FF 100%)",
  },
  header: {
    marginBottom: 32,
  },
  title: {
    fontSize: 28,
    fontWeight: 800,
    margin: "0 0 8px",
    letterSpacing: "-0.02em",
    color: "#0F172A",
  },
  subtitle: {
    fontSize: 15,
    color: "#64748B",
    margin: "0 0 20px",
    lineHeight: 1.5,
  },
  progressBar: {
    height: 6,
    background: "#E2E8F0",
    borderRadius: 3,
    overflow: "hidden",
    marginBottom: 10,
  },
  progressFill: {
    height: "100%",
    background: "linear-gradient(90deg, #059669, #34D399)",
    borderRadius: 3,
    transition: "width 0.4s ease",
  },
  progressLabels: {
    display: "flex",
    gap: 16,
    fontSize: 13,
    color: "#64748B",
  },
  progressLabel: {
    display: "flex",
    alignItems: "center",
    gap: 5,
  },
  dot: {
    width: 8,
    height: 8,
    borderRadius: "50%",
    display: "inline-block",
  },
  section: {
    marginBottom: 28,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 700,
    margin: "0 0 14px",
    display: "flex",
    alignItems: "center",
    gap: 8,
    color: "#1E293B",
  },
  sectionIcon: {
    fontSize: 20,
  },
  card: {
    background: "#FFFFFF",
    borderRadius: 12,
    padding: "16px 18px",
    marginBottom: 10,
    boxShadow: "0 1px 3px rgba(0,0,0,0.06)",
    transition: "all 0.2s ease",
    cursor: "pointer",
  },
  cardMain: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "flex-start",
    gap: 12,
  },
  cardInfo: {
    flex: 1,
    minWidth: 0,
  },
  cardLabel: {
    fontSize: 16,
    fontWeight: 700,
    marginBottom: 4,
    color: "#0F172A",
  },
  cardMeta: {
    fontSize: 13,
    color: "#64748B",
    marginBottom: 8,
  },
  cardTags: {
    display: "flex",
    flexWrap: "wrap",
    gap: 6,
  },
  tag: {
    fontSize: 11,
    fontWeight: 600,
    padding: "3px 10px",
    borderRadius: 20,
    textTransform: "uppercase",
    letterSpacing: "0.03em",
  },
  tagCategory: {
    fontSize: 11,
    padding: "3px 10px",
    borderRadius: 20,
    background: "#F1F5F9",
    color: "#475569",
  },
  tagConfidence: {
    fontSize: 11,
    padding: "3px 10px",
    borderRadius: 20,
    background: "#F1F5F9",
    color: "#94A3B8",
  },
  cardActions: {
    display: "flex",
    gap: 6,
    alignItems: "center",
    flexShrink: 0,
  },
  confirmBtn: {
    width: 36,
    height: 36,
    borderRadius: "50%",
    border: "2px solid #059669",
    background: "#ECFDF5",
    color: "#059669",
    fontSize: 18,
    fontWeight: 700,
    cursor: "pointer",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    transition: "all 0.15s",
  },
  editBtn: {
    width: 36,
    height: 36,
    borderRadius: "50%",
    border: "2px solid #3B82F6",
    background: "#EFF6FF",
    color: "#3B82F6",
    fontSize: 16,
    cursor: "pointer",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    transition: "all 0.15s",
  },
  rejectBtn: {
    width: 36,
    height: 36,
    borderRadius: "50%",
    border: "2px solid #DC2626",
    background: "#FEF2F2",
    color: "#DC2626",
    fontSize: 16,
    fontWeight: 700,
    cursor: "pointer",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    transition: "all 0.15s",
  },
  statusConfirmed: {
    fontSize: 12,
    fontWeight: 600,
    color: "#059669",
    background: "#ECFDF5",
    padding: "6px 12px",
    borderRadius: 20,
  },
  statusRejected: {
    fontSize: 12,
    fontWeight: 600,
    color: "#DC2626",
    background: "#FEF2F2",
    padding: "6px 12px",
    borderRadius: 20,
  },
  editPanel: {
    marginTop: 14,
    padding: "14px 0 4px",
    borderTop: "1px solid #E2E8F0",
  },
  editSection: {
    marginBottom: 12,
  },
  editLabel: {
    fontSize: 12,
    fontWeight: 600,
    color: "#64748B",
    textTransform: "uppercase",
    letterSpacing: "0.05em",
    display: "block",
    marginBottom: 8,
  },
  editOptions: {
    display: "flex",
    flexWrap: "wrap",
    gap: 6,
  },
  editOption: {
    fontSize: 13,
    padding: "6px 14px",
    borderRadius: 8,
    cursor: "pointer",
    transition: "all 0.15s",
  },
  txList: {
    marginTop: 14,
    padding: "12px 0 0",
    borderTop: "1px solid #E2E8F0",
  },
  txListHeader: {
    fontSize: 12,
    fontWeight: 600,
    color: "#94A3B8",
    textTransform: "uppercase",
    letterSpacing: "0.05em",
    marginBottom: 8,
  },
  txRow: {
    display: "flex",
    alignItems: "center",
    gap: 10,
    padding: "6px 0",
    fontSize: 13,
    borderBottom: "1px solid #F1F5F9",
  },
  txDate: {
    color: "#94A3B8",
    width: 60,
    flexShrink: 0,
  },
  txDesc: {
    flex: 1,
    color: "#374151",
    overflow: "hidden",
    textOverflow: "ellipsis",
    whiteSpace: "nowrap",
  },
  txMethod: {
    fontSize: 11,
    color: "#64748B",
    background: "#F1F5F9",
    padding: "2px 8px",
    borderRadius: 4,
    flexShrink: 0,
  },
  txAmount: {
    fontWeight: 600,
    fontVariantNumeric: "tabular-nums",
    flexShrink: 0,
    width: 100,
    textAlign: "right",
  },
  footer: {
    marginTop: 20,
    padding: "20px 0",
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    gap: 10,
  },
  finishButton: {
    width: "100%",
    padding: "14px 24px",
    fontSize: 16,
    fontWeight: 700,
    color: "#FFFFFF",
    background: "linear-gradient(135deg, #059669, #10B981)",
    border: "none",
    borderRadius: 12,
    cursor: "pointer",
    transition: "all 0.2s",
    letterSpacing: "-0.01em",
  },
  skipButton: {
    padding: "8px 16px",
    fontSize: 13,
    color: "#64748B",
    background: "transparent",
    border: "none",
    cursor: "pointer",
    textDecoration: "underline",
  },
  loadingCard: {
    textAlign: "center",
    padding: "80px 32px",
  },
  spinner: {
    width: 48,
    height: 48,
    border: "4px solid #E2E8F0",
    borderTop: "4px solid #059669",
    borderRadius: "50%",
    margin: "0 auto 24px",
    animation: "spin 1s linear infinite",
  },
  loadingTitle: {
    fontSize: 22,
    fontWeight: 700,
    color: "#0F172A",
    marginBottom: 8,
  },
  loadingText: {
    fontSize: 15,
    color: "#64748B",
  },
  doneCard: {
    textAlign: "center",
    padding: "80px 32px",
  },
  doneIcon: {
    width: 64,
    height: 64,
    borderRadius: "50%",
    background: "linear-gradient(135deg, #059669, #10B981)",
    color: "#FFFFFF",
    fontSize: 32,
    fontWeight: 700,
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    margin: "0 auto 20px",
  },
  doneTitle: {
    fontSize: 24,
    fontWeight: 800,
    color: "#0F172A",
    marginBottom: 10,
  },
  doneText: {
    fontSize: 15,
    color: "#475569",
    marginBottom: 8,
    lineHeight: 1.6,
  },
  doneSubtext: {
    fontSize: 13,
    color: "#94A3B8",
  },
};
