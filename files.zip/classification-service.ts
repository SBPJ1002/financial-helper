// ============================================================
// engine/classification-service.ts
// Serviço principal — orquestra ingestão, classificação e onboarding
// ============================================================
//
// COMO USAR:
//
// 1. No sync da Pluggy (webhook ou polling):
//    const service = new ClassificationService(db);
//    await service.processNewTransactions(userId, pluggyTransactions);
//
// 2. No onboarding (primeiro acesso):
//    const groups = await service.generateOnboardingGroups(userId);
//    // → envia pro frontend renderizar a tela de revisão
//    await service.processOnboardingResponse(userId, userResponse);
//
// 3. Quando usuário cria regra manual:
//    await service.createUserRule(userId, ruleData);
//    await service.reclassifyWithNewRule(userId, ruleId);
//
// ============================================================

import { Pool } from 'pg';
import { normalizeTransaction } from './normalizer';
import { detectRecurrences } from './recurrence-detector';
import { classifyTransaction, classifyBatch, getClassificationStats } from './classifier';
import {
  PluggyTransaction,
  NormalizedTransaction,
  ClassificationResult,
  UserClassificationRule,
  RecurrenceGroup,
  KeywordMapping,
  OnboardingGroup,
  OnboardingResponse,
  TransactionType,
} from './types';

export class ClassificationService {
  constructor(private db: Pool) {}

  // ========================================================
  // 1. INGESTÃO — Processa transações novas da Pluggy
  // ========================================================

  async processNewTransactions(
    userId: string,
    rawTransactions: PluggyTransaction[]
  ): Promise<{
    processed: number;
    autoClassified: number;
    pendingReview: number;
  }> {
    // 1. Normaliza todas as transações
    const normalized = rawTransactions.map(normalizeTransaction);

    // 2. Filtra duplicatas (transações já processadas)
    const newTransactions = await this.filterExisting(userId, normalized);
    if (newTransactions.length === 0) {
      return { processed: 0, autoClassified: 0, pendingReview: 0 };
    }

    // 3. Carrega contexto de classificação do usuário
    const [userRules, recurrenceGroups, keywordMappings] = await Promise.all([
      this.getUserRules(userId),
      this.getRecurrenceGroups(userId),
      this.getKeywordMappings(),
    ]);

    // 4. Classifica em lote
    const classifications = classifyBatch(
      newTransactions,
      userRules,
      recurrenceGroups,
      keywordMappings
    );

    // 5. Persiste transações + classificações
    await this.saveTransactions(userId, newTransactions, classifications);

    // 6. Atualiza contadores dos grupos de recorrência
    await this.updateRecurrenceCounts(classifications);

    const stats = getClassificationStats(classifications);
    return {
      processed: stats.total,
      autoClassified: stats.autoClassified,
      pendingReview: stats.pendingReview,
    };
  }

  // ========================================================
  // 2. ONBOARDING — Gera grupos para revisão do usuário
  // ========================================================

  async generateOnboardingGroups(userId: string): Promise<OnboardingGroup[]> {
    // 1. Busca últimos 90 dias de transações do usuário
    const transactions = await this.getRecentTransactions(userId, 90);
    if (transactions.length === 0) return [];

    // 2. Busca grupos de recorrência existentes
    const existingGroups = await this.getRecurrenceGroups(userId);

    // 3. Detecta novos padrões de recorrência
    const patterns = detectRecurrences(transactions, existingGroups);

    // 4. Converte para formato de onboarding
    const onboardingGroups: OnboardingGroup[] = patterns.map((pattern, index) => ({
      id: `onboarding-${index}`,
      type: pattern.isIncome ? 'income' : 'fixed_expense',
      label: pattern.label,
      suggestedCategory: null, // será preenchido pelo keyword match se disponível
      transactions: pattern.transactions.map(tx => ({
        id: tx.pluggyTransactionId,
        description: tx.normalizedDescription,
        amount: tx.amount,
        date: tx.transactionDate.toISOString(),
        paymentMethod: tx.paymentMethod,
      })),
      recurrenceInfo: {
        avgAmount: Math.abs(pattern.avgAmount),
        frequency: 'Mensal',
        dayOfMonth: pattern.avgDayOfMonth,
        occurrences: pattern.transactions.length,
      },
      confidenceScore: this.calculateOnboardingConfidence(pattern),
    }));

    return onboardingGroups;
  }

  /**
   * Processa a resposta do onboarding:
   * - Cria grupos de recorrência confirmados
   * - Cria regras de classificação para os grupos
   * - Reclassifica transações existentes
   */
  async processOnboardingResponse(
    userId: string,
    response: OnboardingResponse
  ): Promise<void> {
    const client = await this.db.connect();

    try {
      await client.query('BEGIN');

      // Grupos confirmados → criar recurrence_groups + regras
      for (const groupId of response.confirmedGroups) {
        // Aqui você buscaria os dados do grupo pelo ID do onboarding
        // e criaria o recurrence_group e regra correspondente
        // (implementação depende de como os dados do onboarding são persistidos)
      }

      // Correções → atualizar tipo/categoria
      for (const correction of response.corrections) {
        // Atualiza o grupo com o tipo correto
      }

      // Grupos rejeitados → marcar transações como variável confirmado
      for (const groupId of response.rejectedGroups) {
        // Marca as transações do grupo como 'user_confirmed' + 'variable_expense'
      }

      await client.query('COMMIT');

      // Reclassifica todas as transações com as novas regras
      await this.reclassifyAll(userId);

    } catch (error) {
      await client.query('ROLLBACK');
      throw error;
    } finally {
      client.release();
    }
  }

  // ========================================================
  // 3. REGRAS DO USUÁRIO
  // ========================================================

  /**
   * Cria uma regra de classificação e aplica retroativamente
   */
  async createUserRule(
    userId: string,
    rule: Omit<UserClassificationRule, 'id' | 'isActive' | 'timesApplied'>
  ): Promise<string> {
    const result = await this.db.query(
      `INSERT INTO user_classification_rules 
       (user_id, match_counterpart_document, match_counterpart_name,
        match_description_contains, match_payment_method,
        match_amount_min, match_amount_max,
        transaction_type, category_id, custom_label, priority)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11)
       RETURNING id`,
      [
        userId,
        rule.matchCounterpartDocument,
        rule.matchCounterpartName,
        rule.matchDescriptionContains,
        rule.matchPaymentMethod,
        rule.matchAmountMin,
        rule.matchAmountMax,
        rule.transactionType,
        rule.categoryId,
        rule.customLabel,
        rule.priority,
      ]
    );

    const ruleId = result.rows[0].id;

    // Aplica retroativamente
    await this.reclassifyWithNewRule(userId, ruleId);

    return ruleId;
  }

  /**
   * Quando o usuário corrige manualmente uma transação,
   * sugere criar uma regra baseada na correção
   */
  async suggestRuleFromCorrection(
    userId: string,
    transactionId: string,
    newType: TransactionType,
    newCategoryId: string | null
  ): Promise<Partial<UserClassificationRule> | null> {
    const txResult = await this.db.query(
      `SELECT * FROM transactions WHERE id = $1 AND user_id = $2`,
      [transactionId, userId]
    );

    if (txResult.rows.length === 0) return null;
    const tx = txResult.rows[0];

    // Sugere regra baseada no critério mais específico disponível
    if (tx.counterpart_document) {
      return {
        matchCounterpartDocument: tx.counterpart_document,
        transactionType: newType,
        categoryId: newCategoryId,
        customLabel: tx.counterpart_name || tx.normalized_description,
        priority: 50,
      };
    }

    if (tx.counterpart_name) {
      return {
        matchCounterpartName: tx.counterpart_name,
        transactionType: newType,
        categoryId: newCategoryId,
        customLabel: tx.counterpart_name,
        priority: 60,
      };
    }

    return null;
  }

  // ========================================================
  // 4. RECLASSIFICAÇÃO
  // ========================================================

  /**
   * Reclassifica todas as transações pendentes de um usuário
   */
  async reclassifyAll(userId: string): Promise<void> {
    const transactions = await this.getUnconfirmedTransactions(userId);
    const [userRules, recurrenceGroups, keywordMappings] = await Promise.all([
      this.getUserRules(userId),
      this.getRecurrenceGroups(userId),
      this.getKeywordMappings(),
    ]);

    for (const tx of transactions) {
      const result = classifyTransaction(tx, userRules, recurrenceGroups, keywordMappings);
      await this.updateTransactionClassification(tx.pluggyTransactionId, result);
    }
  }

  /**
   * Reclassifica transações que podem ser afetadas por uma nova regra
   */
  private async reclassifyWithNewRule(userId: string, ruleId: string): Promise<void> {
    // Busca a regra
    const ruleResult = await this.db.query(
      `SELECT * FROM user_classification_rules WHERE id = $1`,
      [ruleId]
    );
    if (ruleResult.rows.length === 0) return;

    // Reclassifica todas as transações não confirmadas pelo usuário
    await this.reclassifyAll(userId);
  }

  // ========================================================
  // 5. QUERIES DE DASHBOARD
  // ========================================================

  /**
   * Retorna totais por tipo para o dashboard
   */
  async getDashboardSummary(
    userId: string,
    startDate: Date,
    endDate: Date
  ): Promise<{
    totalIncome: number;
    totalFixedExpenses: number;
    totalVariableExpenses: number;
    balance: number;
    pendingReviewCount: number;
  }> {
    const result = await this.db.query(
      `SELECT
         COALESCE(SUM(CASE WHEN transaction_type = 'income' THEN amount END), 0) as total_income,
         COALESCE(SUM(CASE WHEN transaction_type = 'fixed_expense' THEN ABS(amount) END), 0) as total_fixed,
         COALESCE(SUM(CASE WHEN transaction_type = 'variable_expense' THEN ABS(amount) END), 0) as total_variable,
         COUNT(CASE WHEN review_status = 'pending_review' THEN 1 END) as pending_count
       FROM transactions
       WHERE user_id = $1
         AND transaction_date BETWEEN $2 AND $3`,
      [userId, startDate, endDate]
    );

    const row = result.rows[0];
    const income = parseFloat(row.total_income);
    const fixed = parseFloat(row.total_fixed);
    const variable = parseFloat(row.total_variable);

    return {
      totalIncome: income,
      totalFixedExpenses: fixed,
      totalVariableExpenses: variable,
      balance: income - fixed - variable,
      pendingReviewCount: parseInt(row.pending_count),
    };
  }

  // ========================================================
  // PRIVATE HELPERS (queries ao banco)
  // ========================================================

  private async filterExisting(
    userId: string,
    transactions: NormalizedTransaction[]
  ): Promise<NormalizedTransaction[]> {
    if (transactions.length === 0) return [];

    const ids = transactions.map(t => t.pluggyTransactionId);
    const result = await this.db.query(
      `SELECT pluggy_transaction_id FROM transactions 
       WHERE user_id = $1 AND pluggy_transaction_id = ANY($2)`,
      [userId, ids]
    );

    const existingIds = new Set(result.rows.map(r => r.pluggy_transaction_id));
    return transactions.filter(t => !existingIds.has(t.pluggyTransactionId));
  }

  private async getUserRules(userId: string): Promise<UserClassificationRule[]> {
    const result = await this.db.query(
      `SELECT * FROM user_classification_rules 
       WHERE user_id = $1 AND is_active = TRUE 
       ORDER BY priority ASC`,
      [userId]
    );
    return result.rows.map(this.mapRuleRow);
  }

  private async getRecurrenceGroups(userId: string): Promise<RecurrenceGroup[]> {
    const result = await this.db.query(
      `SELECT * FROM recurrence_groups 
       WHERE user_id = $1 AND is_active = TRUE`,
      [userId]
    );
    return result.rows.map(this.mapRecurrenceRow);
  }

  private async getKeywordMappings(): Promise<KeywordMapping[]> {
    const result = await this.db.query(
      `SELECT * FROM keyword_mappings WHERE is_active = TRUE`
    );
    return result.rows.map(this.mapKeywordRow);
  }

  private async getRecentTransactions(
    userId: string,
    days: number
  ): Promise<NormalizedTransaction[]> {
    const result = await this.db.query(
      `SELECT * FROM transactions 
       WHERE user_id = $1 
         AND transaction_date >= NOW() - INTERVAL '${days} days'
       ORDER BY transaction_date DESC`,
      [userId]
    );
    return result.rows.map(this.mapTransactionRow);
  }

  private async getUnconfirmedTransactions(
    userId: string
  ): Promise<NormalizedTransaction[]> {
    const result = await this.db.query(
      `SELECT * FROM transactions 
       WHERE user_id = $1 
         AND review_status NOT IN ('user_confirmed', 'user_corrected')
       ORDER BY transaction_date DESC`,
      [userId]
    );
    return result.rows.map(this.mapTransactionRow);
  }

  private async saveTransactions(
    userId: string,
    transactions: NormalizedTransaction[],
    classifications: Map<string, ClassificationResult>
  ): Promise<void> {
    const client = await this.db.connect();
    try {
      await client.query('BEGIN');

      for (const tx of transactions) {
        const cls = classifications.get(tx.pluggyTransactionId)!;

        await client.query(
          `INSERT INTO transactions (
            user_id, pluggy_transaction_id, pluggy_account_id,
            raw_description, normalized_description, amount, transaction_date,
            payment_method, counterpart_name, counterpart_document, counterpart_pix_key,
            installment_number, installment_total, card_last_four,
            transaction_type, category_id, classification_source,
            confidence_score, review_status, recurrence_group_id
          ) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20)
          ON CONFLICT (pluggy_transaction_id) DO NOTHING`,
          [
            userId, tx.pluggyTransactionId, tx.pluggyAccountId,
            tx.rawDescription, tx.normalizedDescription, tx.amount, tx.transactionDate,
            tx.paymentMethod, tx.counterpartName, tx.counterpartDocument, tx.counterpartPixKey,
            tx.installmentNumber, tx.installmentTotal, tx.cardLastFour,
            cls.transactionType, cls.categoryId, cls.source,
            cls.confidenceScore, cls.reviewStatus, cls.recurrenceGroupId,
          ]
        );

        // Log de classificação
        await client.query(
          `INSERT INTO classification_logs (
            transaction_id, new_type, new_category_id, source,
            confidence_score, rule_id, recurrence_group_id, keyword_mapping_id
          ) SELECT id, $2, $3, $4, $5, $6, $7, $8
            FROM transactions WHERE pluggy_transaction_id = $1`,
          [
            tx.pluggyTransactionId, cls.transactionType, cls.categoryId,
            cls.source, cls.confidenceScore, cls.matchedRuleId,
            cls.recurrenceGroupId, cls.matchedKeywordId,
          ]
        );
      }

      await client.query('COMMIT');
    } catch (error) {
      await client.query('ROLLBACK');
      throw error;
    } finally {
      client.release();
    }
  }

  private async updateTransactionClassification(
    pluggyTransactionId: string,
    result: ClassificationResult
  ): Promise<void> {
    await this.db.query(
      `UPDATE transactions SET
        transaction_type = $2,
        category_id = $3,
        classification_source = $4,
        confidence_score = $5,
        review_status = $6,
        recurrence_group_id = $7
       WHERE pluggy_transaction_id = $1
         AND review_status NOT IN ('user_confirmed', 'user_corrected')`,
      [
        pluggyTransactionId,
        result.transactionType,
        result.categoryId,
        result.source,
        result.confidenceScore,
        result.reviewStatus,
        result.recurrenceGroupId,
      ]
    );
  }

  private async updateRecurrenceCounts(
    classifications: Map<string, ClassificationResult>
  ): Promise<void> {
    const groupIds = new Set<string>();
    for (const cls of classifications.values()) {
      if (cls.recurrenceGroupId) groupIds.add(cls.recurrenceGroupId);
    }

    for (const groupId of groupIds) {
      await this.db.query(
        `UPDATE recurrence_groups SET
          occurrence_count = occurrence_count + 1,
          last_seen_at = NOW()
         WHERE id = $1`,
        [groupId]
      );
    }
  }

  private calculateOnboardingConfidence(pattern: any): number {
    let score = 0.50;
    if (pattern.transactions.length >= 3) score += 0.15;
    if (pattern.amountVariance < 0.05) score += 0.15; // valor bem estável
    if (pattern.amountVariance < 0.10) score += 0.05;
    return Math.min(score, 0.95);
  }

  // Row mappers (adapt to your actual column names)
  private mapRuleRow(row: any): UserClassificationRule {
    return {
      id: row.id,
      userId: row.user_id,
      matchCounterpartDocument: row.match_counterpart_document,
      matchCounterpartName: row.match_counterpart_name,
      matchDescriptionContains: row.match_description_contains,
      matchPaymentMethod: row.match_payment_method,
      matchAmountMin: row.match_amount_min ? parseFloat(row.match_amount_min) : null,
      matchAmountMax: row.match_amount_max ? parseFloat(row.match_amount_max) : null,
      transactionType: row.transaction_type,
      categoryId: row.category_id,
      customLabel: row.custom_label,
      priority: row.priority,
      isActive: row.is_active,
    };
  }

  private mapRecurrenceRow(row: any): RecurrenceGroup {
    return {
      id: row.id,
      userId: row.user_id,
      label: row.label,
      counterpartPattern: row.counterpart_pattern,
      amountAvg: parseFloat(row.amount_avg),
      amountTolerance: parseFloat(row.amount_tolerance),
      dayOfMonthAvg: row.day_of_month_avg,
      dayTolerance: row.day_tolerance,
      transactionType: row.transaction_type,
      categoryId: row.category_id,
      occurrenceCount: row.occurrence_count,
      firstSeenAt: new Date(row.first_seen_at),
      lastSeenAt: new Date(row.last_seen_at),
      isActive: row.is_active,
      confirmedByUser: row.confirmed_by_user,
    };
  }

  private mapKeywordRow(row: any): KeywordMapping {
    return {
      id: row.id,
      keyword: row.keyword,
      matchField: row.match_field,
      matchType: row.match_type,
      transactionType: row.transaction_type,
      categoryId: row.category_id,
      confidenceBoost: parseFloat(row.confidence_boost),
      isActive: row.is_active,
    };
  }

  private mapTransactionRow(row: any): NormalizedTransaction {
    return {
      pluggyTransactionId: row.pluggy_transaction_id,
      pluggyAccountId: row.pluggy_account_id,
      rawDescription: row.raw_description,
      normalizedDescription: row.normalized_description,
      amount: parseFloat(row.amount),
      transactionDate: new Date(row.transaction_date),
      paymentMethod: row.payment_method,
      counterpartName: row.counterpart_name,
      counterpartDocument: row.counterpart_document,
      counterpartPixKey: row.counterpart_pix_key,
      installmentNumber: row.installment_number,
      installmentTotal: row.installment_total,
      cardLastFour: row.card_last_four,
    };
  }
}
