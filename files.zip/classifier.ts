// ============================================================
// engine/classifier.ts
// Motor principal de classificação — orquestra as 3 camadas
// ============================================================

import {
  NormalizedTransaction,
  ClassificationResult,
  UserClassificationRule,
  RecurrenceGroup,
  KeywordMapping,
  TransactionType,
  ClassificationSource,
  ReviewStatus,
} from './types';
import { matchToRecurrenceGroup } from './recurrence-detector';
import { fuzzyMatch } from './utils';

const AUTO_CLASSIFY_THRESHOLD = 0.80;
const REVIEW_THRESHOLD = 0.50;

/**
 * Classifica uma transação passando pelas 3 camadas de classificação:
 * 
 * 1. Regras do Usuário (prioridade máxima, confiança 0.95)
 * 2. Detecção de Recorrência (confiança 0.60-0.85)
 * 3. Heurísticas por Palavra-chave (confiança 0.50-0.80)
 * 4. Fallback: direção do valor (entrada/saída)
 */
export function classifyTransaction(
  transaction: NormalizedTransaction,
  userRules: UserClassificationRule[],
  recurrenceGroups: RecurrenceGroup[],
  keywordMappings: KeywordMapping[]
): ClassificationResult {

  // ========================================
  // Camada 1: Regras do Usuário
  // ========================================
  const ruleMatch = matchUserRule(transaction, userRules);
  if (ruleMatch) {
    return {
      transactionType: ruleMatch.rule.transactionType,
      categoryId: ruleMatch.rule.categoryId,
      source: 'user_rule',
      confidenceScore: 0.95,
      reviewStatus: 'auto_classified',
      recurrenceGroupId: null,
      matchedRuleId: ruleMatch.rule.id,
      matchedKeywordId: null,
    };
  }

  // ========================================
  // Camada 2: Recorrência
  // ========================================
  const recurrenceMatch = matchToRecurrenceGroup(transaction, recurrenceGroups);
  if (recurrenceMatch) {
    const confidence = calculateRecurrenceConfidence(recurrenceMatch);
    return {
      transactionType: recurrenceMatch.transactionType,
      categoryId: recurrenceMatch.categoryId,
      source: 'recurrence',
      confidenceScore: confidence,
      reviewStatus: confidence >= AUTO_CLASSIFY_THRESHOLD 
        ? 'auto_classified' 
        : 'pending_review',
      recurrenceGroupId: recurrenceMatch.id,
      matchedRuleId: null,
      matchedKeywordId: null,
    };
  }

  // ========================================
  // Camada 3: Palavras-chave / Heurísticas
  // ========================================
  const keywordMatch = matchKeyword(transaction, keywordMappings);
  if (keywordMatch) {
    const confidence = keywordMatch.mapping.confidenceBoost;
    return {
      transactionType: keywordMatch.mapping.transactionType,
      categoryId: keywordMatch.mapping.categoryId,
      source: 'keyword',
      confidenceScore: confidence,
      reviewStatus: confidence >= AUTO_CLASSIFY_THRESHOLD 
        ? 'auto_classified' 
        : 'pending_review',
      recurrenceGroupId: null,
      matchedRuleId: null,
      matchedKeywordId: keywordMatch.mapping.id,
    };
  }

  // ========================================
  // Camada 4: Fallback por direção do valor
  // ========================================
  return classifyByDirection(transaction);
}

/**
 * Classifica um lote de transações de uma vez.
 * Útil para o processamento inicial no onboarding.
 */
export function classifyBatch(
  transactions: NormalizedTransaction[],
  userRules: UserClassificationRule[],
  recurrenceGroups: RecurrenceGroup[],
  keywordMappings: KeywordMapping[]
): Map<string, ClassificationResult> {
  const results = new Map<string, ClassificationResult>();

  for (const tx of transactions) {
    const result = classifyTransaction(tx, userRules, recurrenceGroups, keywordMappings);
    results.set(tx.pluggyTransactionId, result);
  }

  return results;
}

/**
 * Retorna estatísticas de classificação para um lote
 */
export function getClassificationStats(results: Map<string, ClassificationResult>) {
  let autoClassified = 0;
  let pendingReview = 0;
  let income = 0;
  let fixedExpense = 0;
  let variableExpense = 0;
  const bySource: Record<ClassificationSource, number> = {
    user_rule: 0,
    recurrence: 0,
    keyword: 0,
    default: 0,
    manual: 0,
  };

  for (const result of results.values()) {
    if (result.reviewStatus === 'auto_classified') autoClassified++;
    if (result.reviewStatus === 'pending_review') pendingReview++;
    if (result.transactionType === 'income') income++;
    if (result.transactionType === 'fixed_expense') fixedExpense++;
    if (result.transactionType === 'variable_expense') variableExpense++;
    bySource[result.source]++;
  }

  return {
    total: results.size,
    autoClassified,
    pendingReview,
    byType: { income, fixedExpense, variableExpense },
    bySource,
  };
}

// ============================================================
// Match functions
// ============================================================

function matchUserRule(
  tx: NormalizedTransaction,
  rules: UserClassificationRule[]
): { rule: UserClassificationRule } | null {
  // Ordena por prioridade (menor = maior prioridade)
  const sortedRules = [...rules]
    .filter(r => r.isActive)
    .sort((a, b) => a.priority - b.priority);

  for (const rule of sortedRules) {
    if (doesRuleMatch(tx, rule)) {
      return { rule };
    }
  }

  return null;
}

function doesRuleMatch(
  tx: NormalizedTransaction,
  rule: UserClassificationRule
): boolean {
  // Todos os critérios definidos devem dar match (AND logic)
  
  if (rule.matchCounterpartDocument) {
    if (tx.counterpartDocument !== rule.matchCounterpartDocument) return false;
  }

  if (rule.matchCounterpartName) {
    if (!tx.counterpartName) return false;
    if (!fuzzyMatch(rule.matchCounterpartName, tx.counterpartName, 0.75)) return false;
  }

  if (rule.matchDescriptionContains) {
    const keyword = rule.matchDescriptionContains.toLowerCase();
    const desc = tx.normalizedDescription.toLowerCase();
    const raw = tx.rawDescription.toLowerCase();
    if (!desc.includes(keyword) && !raw.includes(keyword)) return false;
  }

  if (rule.matchPaymentMethod) {
    if (tx.paymentMethod !== rule.matchPaymentMethod) return false;
  }

  if (rule.matchAmountMin !== null) {
    if (Math.abs(tx.amount) < rule.matchAmountMin) return false;
  }

  if (rule.matchAmountMax !== null) {
    if (Math.abs(tx.amount) > rule.matchAmountMax) return false;
  }

  return true;
}

function matchKeyword(
  tx: NormalizedTransaction,
  mappings: KeywordMapping[]
): { mapping: KeywordMapping } | null {
  // Ordena por confiança decrescente pra pegar o match mais confiável
  const sorted = [...mappings]
    .filter(m => m.isActive)
    .sort((a, b) => b.confidenceBoost - a.confidenceBoost);

  for (const mapping of sorted) {
    const fieldValue = getFieldValue(tx, mapping.matchField);
    if (!fieldValue) continue;

    const keyword = mapping.keyword.toLowerCase();
    const value = fieldValue.toLowerCase();

    let matched = false;
    switch (mapping.matchType) {
      case 'exact':
        matched = value === keyword;
        break;
      case 'starts_with':
        matched = value.startsWith(keyword);
        break;
      case 'contains':
      default:
        matched = value.includes(keyword);
        break;
    }

    if (matched) {
      return { mapping };
    }
  }

  return null;
}

function getFieldValue(
  tx: NormalizedTransaction,
  field: string
): string | null {
  switch (field) {
    case 'normalized_description':
      return tx.normalizedDescription;
    case 'counterpart_name':
      return tx.counterpartName;
    case 'raw_description':
      return tx.rawDescription;
    default:
      return null;
  }
}

function calculateRecurrenceConfidence(group: RecurrenceGroup): number {
  let confidence = 0.60; // base

  // Mais ocorrências = mais confiável
  if (group.occurrenceCount >= 6) confidence += 0.20;
  else if (group.occurrenceCount >= 3) confidence += 0.15;
  else confidence += 0.05;

  // Confirmação do usuário = máxima confiança
  if (group.confirmedByUser) confidence += 0.15;

  return Math.min(confidence, 0.95);
}

function classifyByDirection(tx: NormalizedTransaction): ClassificationResult {
  const isIncome = tx.amount > 0;

  return {
    transactionType: isIncome ? 'income' : 'variable_expense',
    categoryId: null,
    source: 'default',
    confidenceScore: isIncome ? 0.40 : 0.20,
    reviewStatus: 'pending_review',
    recurrenceGroupId: null,
    matchedRuleId: null,
    matchedKeywordId: null,
  };
}
