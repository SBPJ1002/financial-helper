// ============================================================
// engine/index.ts
// Barrel exports — importe tudo a partir daqui
// ============================================================
//
// Uso:
//   import { ClassificationService } from './engine';
//   import { normalizeTransaction } from './engine';
//   import type { PluggyTransaction, ClassificationResult } from './engine';
//

export { ClassificationService } from './classification-service';
export { normalizeTransaction, normalizeDescription, detectPaymentMethod } from './normalizer';
export { detectRecurrences, matchToRecurrenceGroup } from './recurrence-detector';
export { classifyTransaction, classifyBatch, getClassificationStats } from './classifier';
export { fuzzyMatch, formatCurrency, formatDate, groupBy, removeAccents } from './utils';

export type {
  TransactionType,
  PaymentMethod,
  ClassificationSource,
  ReviewStatus,
  PluggyTransaction,
  NormalizedTransaction,
  ClassificationResult,
  UserClassificationRule,
  RecurrenceGroup,
  KeywordMapping,
  OnboardingGroup,
  OnboardingResponse,
} from './types';
