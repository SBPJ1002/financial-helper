// ============================================================
// engine/normalizer.ts
// Normaliza transações brutas da Pluggy para formato interno
// ============================================================

import {
  PluggyTransaction,
  NormalizedTransaction,
  PaymentMethod,
} from './types';

/**
 * Pipeline de normalização:
 * 1. Detecta método de pagamento
 * 2. Extrai dados do recebedor/pagador
 * 3. Limpa e normaliza a descrição
 */
export function normalizeTransaction(raw: PluggyTransaction): NormalizedTransaction {
  return {
    pluggyTransactionId: raw.id,
    pluggyAccountId: raw.accountId,
    rawDescription: raw.description,
    normalizedDescription: normalizeDescription(raw.description),
    amount: raw.amount,
    transactionDate: new Date(raw.date),
    paymentMethod: detectPaymentMethod(raw),
    counterpartName: extractCounterpartName(raw),
    counterpartDocument: extractCounterpartDocument(raw),
    counterpartPixKey: extractPixKey(raw),
    installmentNumber: raw.creditCardMetadata?.installmentNumber ?? null,
    installmentTotal: raw.creditCardMetadata?.totalInstallments ?? null,
    cardLastFour: extractCardLastFour(raw),
  };
}

/**
 * Normaliza a descrição da transação:
 * - Remove códigos bancários e hashes
 * - Padroniza casing
 * - Remove espaços extras
 * - Remove caracteres especiais desnecessários
 */
export function normalizeDescription(description: string): string {
  let normalized = description;

  // Remove padrões comuns de códigos bancários
  // Ex: "PAG*JoseSilva - 12345678" → "PAG JoseSilva"
  const bankCodePatterns = [
    /\b\d{6,}\b/g,                          // sequências longas de números
    /\b[A-F0-9]{8,}\b/gi,                   // hashes hexadecimais
    /\s*-\s*\d+\s*$/,                        // " - 12345" no final
    /^\d{2}\/\d{2}\s*/,                      // "05/01 " no início (data)
    /\bNSU:\s*\d+/gi,                        // NSU: 123456
    /\bAUT:\s*\d+/gi,                        // AUT: 123456
    /\bDOC:\s*\d+/gi,                        // DOC: 123456
    /\b\d{2}\.\d{3}\.\d{3}\/\d{4}-\d{2}\b/, // CNPJ inline (mantemos separado)
    /\b\d{3}\.\d{3}\.\d{3}-\d{2}\b/,        // CPF inline (mantemos separado)
  ];

  for (const pattern of bankCodePatterns) {
    normalized = normalized.replace(pattern, ' ');
  }

  // Remove prefixos comuns de bancos
  const bankPrefixes = [
    /^PAG\*/i,
    /^PGTO\s*/i,
    /^RECTO?\s*/i,
    /^TED\s*/i,
    /^DOC\s*/i,
    /^PIX\s*/i,
    /^DEB\.AUT\.\s*/i,
    /^TRANSF\s*/i,
    /^COMPRA\s+CARTAO\s*/i,
    /^PAGAMENTO\s+EFETUADO\s*/i,
  ];

  for (const prefix of bankPrefixes) {
    normalized = normalized.replace(prefix, '');
  }

  // Limpa e padroniza
  normalized = normalized
    .replace(/[*#]+/g, ' ')           // remove * e #
    .replace(/\s+/g, ' ')            // normaliza espaços
    .trim()
    .toLowerCase();

  // Capitaliza primeira letra de cada palavra significativa
  normalized = normalized
    .split(' ')
    .map(word => {
      if (word.length <= 2) return word; // preposições
      return word.charAt(0).toUpperCase() + word.slice(1);
    })
    .join(' ');

  return normalized || description; // fallback para original se ficou vazio
}

/**
 * Detecta o método de pagamento com base nos dados da Pluggy
 */
export function detectPaymentMethod(raw: PluggyTransaction): PaymentMethod {
  // Cartão de crédito
  if (raw.creditCardMetadata) {
    return 'credit_card';
  }

  const paymentMethodStr = raw.paymentData?.paymentMethod?.toUpperCase() ?? '';
  const descUpper = raw.description.toUpperCase();

  // PIX
  if (
    paymentMethodStr.includes('PIX') ||
    descUpper.includes('PIX')
  ) {
    return 'pix';
  }

  // Boleto
  if (
    paymentMethodStr.includes('BOLETO') ||
    descUpper.includes('BOLETO') ||
    descUpper.includes('TITULO')
  ) {
    return 'boleto';
  }

  // Débito automático
  if (
    descUpper.includes('DEB.AUT') ||
    descUpper.includes('DEBITO AUTOMATICO') ||
    descUpper.includes('DEB AUTO')
  ) {
    return 'auto_debit';
  }

  // Cartão de débito
  if (
    descUpper.includes('COMPRA CARTAO') ||
    descUpper.includes('COMPRA NO DEBITO')
  ) {
    return 'debit_card';
  }

  // Transferência
  if (
    descUpper.includes('TED') ||
    descUpper.includes('DOC') ||
    descUpper.includes('TRANSF')
  ) {
    return 'transfer';
  }

  return 'other';
}

/**
 * Extrai o nome do recebedor/pagador
 * Prioridade: merchant.name > paymentData.receiver/payer > parsing da descrição
 */
export function extractCounterpartName(raw: PluggyTransaction): string | null {
  // 1. Merchant name (mais confiável)
  if (raw.merchant?.name) {
    return normalizeName(raw.merchant.name);
  }

  if (raw.merchant?.businessName) {
    return normalizeName(raw.merchant.businessName);
  }

  // 2. Payment data receiver/payer
  const isCredit = raw.type === 'CREDIT';
  const counterpart = isCredit
    ? raw.paymentData?.payer
    : raw.paymentData?.receiver;

  if (counterpart?.name) {
    return normalizeName(counterpart.name);
  }

  // 3. Tentar extrair da descrição (após prefixo)
  const descClean = raw.description
    .replace(/^(PAG\*|PIX\s|TED\s|TRANSF\s)/i, '')
    .trim();

  // Se sobrou algo que parece um nome (pelo menos 2 palavras, sem muitos números)
  const words = descClean.split(/\s+/);
  if (words.length >= 2 && !/\d{4,}/.test(descClean)) {
    return normalizeName(descClean.split(/\s*-\s*/)[0].trim());
  }

  return null;
}

/**
 * Extrai CPF/CNPJ do recebedor/pagador
 */
export function extractCounterpartDocument(raw: PluggyTransaction): string | null {
  // CNPJ do merchant
  if (raw.merchant?.cnpj) {
    return cleanDocument(raw.merchant.cnpj);
  }

  // Documento via paymentData
  const isCredit = raw.type === 'CREDIT';
  const counterpart = isCredit
    ? raw.paymentData?.payer
    : raw.paymentData?.receiver;

  if (counterpart?.documentNumber?.value) {
    return cleanDocument(counterpart.documentNumber.value);
  }

  // Tentar extrair da descrição
  const cnpjMatch = raw.description.match(/(\d{2}\.?\d{3}\.?\d{3}\/?\d{4}-?\d{2})/);
  if (cnpjMatch) return cleanDocument(cnpjMatch[1]);

  const cpfMatch = raw.description.match(/(\d{3}\.?\d{3}\.?\d{3}-?\d{2})/);
  if (cpfMatch) return cleanDocument(cpfMatch[1]);

  return null;
}

/**
 * Extrai chave PIX quando disponível
 */
export function extractPixKey(raw: PluggyTransaction): string | null {
  if (!raw.paymentData) return null;
  
  // A Pluggy pode trazer a chave PIX em referenceNumber pra transações PIX
  const descUpper = raw.description.toUpperCase();
  const isPixTransaction = 
    descUpper.includes('PIX') || 
    raw.paymentData.paymentMethod?.toUpperCase().includes('PIX');

  if (isPixTransaction && raw.paymentData.referenceNumber) {
    return raw.paymentData.referenceNumber;
  }

  return null;
}

/**
 * Extrai últimos 4 dígitos do cartão
 */
function extractCardLastFour(raw: PluggyTransaction): string | null {
  if (raw.creditCardMetadata?.cardNumber) {
    const digits = raw.creditCardMetadata.cardNumber.replace(/\D/g, '');
    return digits.slice(-4) || null;
  }
  return null;
}

// ---- Helpers ----

function normalizeName(name: string): string {
  return name
    .replace(/[*#]+/g, '')
    .replace(/\s+/g, ' ')
    .trim()
    .split(' ')
    .map(w => w.charAt(0).toUpperCase() + w.slice(1).toLowerCase())
    .join(' ');
}

function cleanDocument(doc: string): string {
  return doc.replace(/[.\-\/]/g, '');
}
