// ============================================================
// engine/recurrence-detector.ts
// Detecta transações recorrentes agrupando por padrão
// ============================================================

import { NormalizedTransaction, RecurrenceGroup, TransactionType } from './types';
import { fuzzyMatch } from './utils';

interface TransactionCandidate {
  transaction: NormalizedTransaction;
  counterpartKey: string; // chave de agrupamento normalizada
}

interface DetectedPattern {
  counterpartKey: string;
  label: string;
  transactions: NormalizedTransaction[];
  avgAmount: number;
  avgDayOfMonth: number;
  amountVariance: number; // 0-1, quão estável é o valor
  isIncome: boolean;
}

const MIN_OCCURRENCES = 2;      // mínimo pra considerar recorrência
const AMOUNT_TOLERANCE = 0.15;  // 15% de variação no valor
const DAY_TOLERANCE = 7;        // ±7 dias no mês

/**
 * Detecta padrões de recorrência em um conjunto de transações.
 * Deve receber 60-90 dias de histórico para bons resultados.
 */
export function detectRecurrences(
  transactions: NormalizedTransaction[],
  existingGroups: RecurrenceGroup[] = []
): DetectedPattern[] {
  // 1. Agrupa transações por recebedor/pagador
  const grouped = groupByCounterpart(transactions);

  // 2. Para cada grupo, verifica se há padrão de recorrência
  const patterns: DetectedPattern[] = [];

  for (const [key, group] of grouped.entries()) {
    // Precisa de pelo menos MIN_OCCURRENCES transações
    if (group.length < MIN_OCCURRENCES) continue;

    // Ignora se já existe grupo ativo confirmado para este padrão
    const alreadyTracked = existingGroups.some(
      g => g.isActive && g.counterpartPattern === key
    );
    if (alreadyTracked) continue;

    // Separa por direção (entrada vs saída)
    const debits = group.filter(t => t.amount < 0);
    const credits = group.filter(t => t.amount > 0);

    // Analisa cada direção separadamente
    if (debits.length >= MIN_OCCURRENCES) {
      const pattern = analyzePattern(key, debits, false);
      if (pattern) patterns.push(pattern);
    }

    if (credits.length >= MIN_OCCURRENCES) {
      const pattern = analyzePattern(key, credits, true);
      if (pattern) patterns.push(pattern);
    }
  }

  // 3. Ordena por confiança (mais ocorrências + menor variação = mais confiável)
  return patterns.sort((a, b) => {
    const scoreA = a.transactions.length * (1 - a.amountVariance);
    const scoreB = b.transactions.length * (1 - b.amountVariance);
    return scoreB - scoreA;
  });
}

/**
 * Tenta associar uma nova transação a um grupo de recorrência existente
 */
export function matchToRecurrenceGroup(
  transaction: NormalizedTransaction,
  groups: RecurrenceGroup[]
): RecurrenceGroup | null {
  const txCounterpartKey = buildCounterpartKey(transaction);
  const txAmount = Math.abs(transaction.amount);
  const txDay = transaction.transactionDate.getDate();

  for (const group of groups) {
    if (!group.isActive) continue;

    // Match por padrão do recebedor
    const counterpartMatch =
      group.counterpartPattern === txCounterpartKey ||
      (group.counterpartPattern && txCounterpartKey &&
        fuzzyMatch(group.counterpartPattern, txCounterpartKey, 0.8));

    if (!counterpartMatch) continue;

    // Match por valor (dentro da tolerância)
    const avgAmount = Math.abs(group.amountAvg);
    const amountDiff = Math.abs(txAmount - avgAmount) / avgAmount;

    if (amountDiff > group.amountTolerance) continue;

    // Match por dia do mês (dentro da tolerância)
    if (group.dayOfMonthAvg !== null) {
      const dayDiff = Math.abs(txDay - group.dayOfMonthAvg);
      // Considera wrap-around (ex: dia 30 → dia 2)
      const dayDiffWrapped = Math.min(dayDiff, 30 - dayDiff);
      if (dayDiffWrapped > group.dayTolerance) continue;
    }

    return group;
  }

  return null;
}

// ============================================================
// Funções internas
// ============================================================

/**
 * Agrupa transações pela chave do recebedor/pagador
 */
function groupByCounterpart(
  transactions: NormalizedTransaction[]
): Map<string, NormalizedTransaction[]> {
  const groups = new Map<string, NormalizedTransaction[]>();

  for (const tx of transactions) {
    const key = buildCounterpartKey(tx);
    if (!key) continue; // sem info suficiente pra agrupar

    // Tenta fazer fuzzy match com chaves existentes
    let matchedKey = key;
    for (const existingKey of groups.keys()) {
      if (fuzzyMatch(existingKey, key, 0.8)) {
        matchedKey = existingKey; // usa a chave existente
        break;
      }
    }

    const existing = groups.get(matchedKey) || [];
    existing.push(tx);
    groups.set(matchedKey, existing);
  }

  return groups;
}

/**
 * Constrói uma chave de agrupamento para o recebedor/pagador.
 * Prioridade: CNPJ > nome normalizado > descrição normalizada
 */
function buildCounterpartKey(tx: NormalizedTransaction): string | null {
  // CNPJ/CPF é o identificador mais estável
  if (tx.counterpartDocument) {
    return `doc:${tx.counterpartDocument}`;
  }

  // Nome do recebedor
  if (tx.counterpartName) {
    return `name:${tx.counterpartName.toLowerCase().trim()}`;
  }

  // Fallback: descrição normalizada (menos confiável)
  if (tx.normalizedDescription) {
    // Pega as primeiras 3 palavras significativas como chave
    const words = tx.normalizedDescription
      .toLowerCase()
      .split(' ')
      .filter(w => w.length > 2)
      .slice(0, 3);

    if (words.length >= 2) {
      return `desc:${words.join(' ')}`;
    }
  }

  return null;
}

/**
 * Analisa um grupo de transações para verificar se há padrão de recorrência
 */
function analyzePattern(
  counterpartKey: string,
  transactions: NormalizedTransaction[],
  isIncome: boolean
): DetectedPattern | null {
  const amounts = transactions.map(t => Math.abs(t.amount));
  const days = transactions.map(t => t.transactionDate.getDate());

  const avgAmount = amounts.reduce((a, b) => a + b, 0) / amounts.length;
  const avgDay = Math.round(days.reduce((a, b) => a + b, 0) / days.length);

  // Calcula variância do valor (0 = constante, 1 = alta variação)
  const amountVariance = amounts.length > 1
    ? amounts.reduce((sum, a) => sum + Math.pow((a - avgAmount) / avgAmount, 2), 0) / amounts.length
    : 0;

  // Se a variância do valor é muito alta, provavelmente não é recorrente
  // (ex: compras variáveis no mesmo estabelecimento)
  if (amountVariance > AMOUNT_TOLERANCE * 3) return null;

  // Verifica se os dias são razoavelmente consistentes
  const dayVariance = days.length > 1
    ? days.reduce((sum, d) => {
        const diff = Math.abs(d - avgDay);
        return sum + Math.min(diff, 30 - diff); // wrap-around
      }, 0) / days.length
    : 0;

  if (dayVariance > DAY_TOLERANCE) return null;

  // Verifica periodicidade mensal
  // Ordena por data e verifica gaps entre transações
  const sorted = [...transactions].sort(
    (a, b) => a.transactionDate.getTime() - b.transactionDate.getTime()
  );

  const gaps: number[] = [];
  for (let i = 1; i < sorted.length; i++) {
    const diffDays = Math.round(
      (sorted[i].transactionDate.getTime() - sorted[i - 1].transactionDate.getTime()) /
      (1000 * 60 * 60 * 24)
    );
    gaps.push(diffDays);
  }

  // Gap médio deveria ser ~30 dias para mensal
  if (gaps.length > 0) {
    const avgGap = gaps.reduce((a, b) => a + b, 0) / gaps.length;
    // Aceita entre 25 e 35 dias de gap médio
    if (avgGap < 20 || avgGap > 40) return null;
  }

  // Tudo ok, temos um padrão!
  const label = buildLabel(transactions[0], isIncome);

  return {
    counterpartKey,
    label,
    transactions,
    avgAmount: isIncome ? avgAmount : -avgAmount,
    avgDayOfMonth: avgDay,
    amountVariance,
    isIncome,
  };
}

/**
 * Gera um label legível para o grupo de recorrência
 */
function buildLabel(sample: NormalizedTransaction, isIncome: boolean): string {
  const prefix = isIncome ? 'Receita' : 'Gasto';

  if (sample.counterpartName) {
    return `${prefix} - ${sample.counterpartName}`;
  }

  return `${prefix} - ${sample.normalizedDescription}`;
}
