// ============================================================
// types/classification.ts
// Tipos centrais do motor de classificação financeira
// ============================================================

export type TransactionType = 'income' | 'fixed_expense' | 'variable_expense';
export type PaymentMethod = 'pix' | 'boleto' | 'credit_card' | 'debit_card' | 'auto_debit' | 'transfer' | 'other';
export type ClassificationSource = 'user_rule' | 'recurrence' | 'keyword' | 'default' | 'manual';
export type ReviewStatus = 'auto_classified' | 'pending_review' | 'user_confirmed' | 'user_corrected';

// ---- Pluggy raw data ----

export interface PluggyTransaction {
  id: string;
  accountId: string;
  description: string;
  descriptionRaw?: string;
  amount: number;
  date: string;
  type: 'DEBIT' | 'CREDIT';
  category?: {
    id: string;
    description: string;
  };
  paymentData?: {
    paymentMethod?: string;
    referenceNumber?: string;
    payer?: {
      name?: string;
      documentNumber?: { value: string; type: string };
    };
    receiver?: {
      name?: string;
      documentNumber?: { value: string; type: string };
    };
  };
  merchant?: {
    name?: string;
    cnpj?: string;
    businessName?: string;
  };
  creditCardMetadata?: {
    installmentNumber?: number;
    totalInstallments?: number;
    cardNumber?: string;
  };
}

// ---- Normalized transaction ----

export interface NormalizedTransaction {
  pluggyTransactionId: string;
  pluggyAccountId: string;
  rawDescription: string;
  normalizedDescription: string;
  amount: number;
  transactionDate: Date;
  paymentMethod: PaymentMethod;
  counterpartName: string | null;
  counterpartDocument: string | null;
  counterpartPixKey: string | null;
  installmentNumber: number | null;
  installmentTotal: number | null;
  cardLastFour: string | null;
}

// ---- Classification result ----

export interface ClassificationResult {
  transactionType: TransactionType;
  categoryId: string | null;
  source: ClassificationSource;
  confidenceScore: number;
  reviewStatus: ReviewStatus;
  recurrenceGroupId: string | null;
  matchedRuleId: string | null;
  matchedKeywordId: string | null;
}

// ---- User rule ----

export interface UserClassificationRule {
  id: string;
  userId: string;
  matchCounterpartDocument: string | null;
  matchCounterpartName: string | null;
  matchDescriptionContains: string | null;
  matchPaymentMethod: PaymentMethod | null;
  matchAmountMin: number | null;
  matchAmountMax: number | null;
  transactionType: TransactionType;
  categoryId: string | null;
  customLabel: string | null;
  priority: number;
  isActive: boolean;
}

// ---- Recurrence group ----

export interface RecurrenceGroup {
  id: string;
  userId: string;
  label: string;
  counterpartPattern: string | null;
  amountAvg: number;
  amountTolerance: number;
  dayOfMonthAvg: number | null;
  dayTolerance: number;
  transactionType: TransactionType;
  categoryId: string | null;
  occurrenceCount: number;
  firstSeenAt: Date;
  lastSeenAt: Date;
  isActive: boolean;
  confirmedByUser: boolean;
}

// ---- Keyword mapping ----

export interface KeywordMapping {
  id: string;
  keyword: string;
  matchField: 'normalized_description' | 'counterpart_name' | 'raw_description';
  matchType: 'contains' | 'starts_with' | 'exact';
  transactionType: TransactionType;
  categoryId: string | null;
  confidenceBoost: number;
  isActive: boolean;
}

// ---- Onboarding ----

export interface OnboardingGroup {
  id: string;
  type: 'income' | 'fixed_expense';
  label: string;
  suggestedCategory: string | null;
  transactions: {
    id: string;
    description: string;
    amount: number;
    date: string;
    paymentMethod: PaymentMethod;
  }[];
  recurrenceInfo: {
    avgAmount: number;
    frequency: string;
    dayOfMonth: number;
    occurrences: number;
  };
  confidenceScore: number;
}

export interface OnboardingResponse {
  confirmedGroups: string[];           // IDs dos grupos confirmados
  rejectedGroups: string[];            // IDs rejeitados (voltam a ser variável)
  corrections: {
    groupId: string;
    newType: TransactionType;
    newCategoryId?: string;
  }[];
}
